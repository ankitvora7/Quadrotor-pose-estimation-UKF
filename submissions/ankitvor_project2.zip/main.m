clear all
close all
clc
load('./imu/imuRaw2.mat')
timu = ts;
load('./cam/cam2.mat')
tcam = ts;
load('./vicon/viconRot2.mat')
tvicon = ts;
UnscentedKalmanFilter(vals,rots,cam,timu,tvicon,tcam);