addpath(genpath('./'))
imuParams = getIMUparams();