clear all
clc
close all
load('./imu/imuRaw1.mat');
init;
xk = [1 0 0 0]';
tnow =0; tprev = 0;
allpos = [0 0 0]';
for i=1:size(vals,2)
    i
    tnow = ts(i);
    dt = tnow-tprev;
    tprev = tnow;
    if i==1
        continue
    end
    z = processIMUData(vals(:,i),imuParams);
    zomg = z(4:end);
    alpha = norm(zomg)*dt; ecc = normc(zomg);
    qDelta = [cos(alpha/2);ecc.*sin(alpha/2)];
    xk_new = quatMultiply(xk,qDelta);
    pos = quat2eul(xk_new','ZYX');
    xk = xk_new;
    allpos(:,i) = pos;
    allgVect(:,i) = z(1:3);
end


% Convert vicon data to euler angles to check your values
load('./vicon/viconRot1.mat');
[actualAngles,actualgVect] = computeViconAngles(rots);


% Plot to see values
subplot(3,2,1)  
plot(1:size(allpos,2),allpos(1,:))
hold on
plot(1:size(actualAngles,2),actualAngles(1,:));

subplot(3,2,3)  
plot(1:size(allpos,2),allpos(2,:))
hold on
plot(1:size(actualAngles,2),actualAngles(2,:));

subplot(3,2,5)  
plot(1:size(allpos,2),allpos(3,:))
hold on
plot(1:size(actualAngles,2),actualAngles(3,:));

subplot(3,2,2)  
plot(1:size(allgVect,2),allgVect(1,:))
hold on
plot(1:size(actualgVect,2),actualgVect(1,:));

subplot(3,2,4)  
plot(1:size(allgVect,2),allgVect(2,:))
hold on
plot(1:size(actualgVect,2),actualgVect(2,:));

subplot(3,2,6)  
plot(1:size(allgVect,2),allgVect(3,:))
hold on
plot(1:size(actualgVect,2),actualgVect(3,:));