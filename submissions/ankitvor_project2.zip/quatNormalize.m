function [n] = quatNormalize(q)
% Normalize a quaternion

n = normc(q);


end

